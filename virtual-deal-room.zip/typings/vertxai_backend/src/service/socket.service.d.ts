
declare interface offerType {}

declare interface newMessageType {}
